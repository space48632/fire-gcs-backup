# drone_manager.py
"""
기본 실행용 DroneManager 예제입니다.

실제 MAVLink / Pixhawk 코드가 있다면 이 파일을 기존 drone_manager.py로
교체하면 됩니다.

필수 인터페이스:
- DroneManager(callback=...)
- set_connection_string(...)
- start()
- stop()
- send_command(...)
"""

import threading
import time
import random


class DroneManager:
    def __init__(self, callback=None):
        self.callback = callback
        self.connection_string = None
        self.running = False
        self.worker = None

    def set_connection_string(self, connection_string):
        self.connection_string = connection_string

    def start(self):
        if self.running:
            return

        self.running = True
        self.worker = threading.Thread(
            target=self._mock_telemetry_loop,
            daemon=True,
        )
        self.worker.start()

        if self.callback:
            self.callback(
                "DRONE_STATUS",
                {
                    "connected": True,
                    "connection": self.connection_string,
                },
            )

    def stop(self):
        self.running = False

        if self.callback:
            self.callback(
                "DRONE_STATUS",
                {"connected": False},
            )

    def send_command(self, command):
        if self.callback:
            self.callback(
                "COMMAND_ACK",
                {
                    "command": command,
                    "accepted": True,
                },
            )

    def _mock_telemetry_loop(self):
        altitude = 0.0
        battery = 100

        while self.running:
            altitude = max(0, altitude + random.uniform(-0.2, 0.8))
            battery = max(0, battery - random.choice([0, 0, 0, 1]))

            telemetry = {
                "altitude": round(altitude, 1),
                "speed": round(random.uniform(0, 15), 1),
                "battery": battery,
                "satellites": random.randint(12, 20),
                "mode": "GUIDED",
                "armed": False,
                "lat": 37.5665,
                "lng": 126.9780,
            }

            if self.callback:
                self.callback("TELEMETRY", telemetry)

            time.sleep(1)
