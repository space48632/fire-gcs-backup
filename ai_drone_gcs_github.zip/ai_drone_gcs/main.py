# main.py
import os
import asyncio
import json
import random
import webbrowser
import threading
import uuid
import time

from collections import deque
from datetime import datetime
from zoneinfo import ZoneInfo
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

from drone_manager import DroneManager
from video_manager import VideoManager

base_dir = os.path.dirname(os.path.abspath(__file__))
static_dir = os.path.join(base_dir, "static")
os.makedirs(static_dir, exist_ok=True)

KST = ZoneInfo("Asia/Seoul")
main_loop = None

event_history = deque(maxlen=500)
chat_history = deque(maxlen=200)
alerts = {}

gcs_state = {
    "drone_connected": False,
    "video_running": False,
    "connection_string": None,
    "last_command": None,
    "server_started": None,
}


def now():
    return datetime.now(KST).isoformat(timespec="seconds")


def create_event(event_type, data=None, level="INFO"):
    event = {
        "id": str(uuid.uuid4()),
        "type": event_type,
        "level": level,
        "data": data or {},
        "timestamp": now(),
    }
    event_history.append(event)
    return event


class ConnectionManager:
    def __init__(self):
        self.connections = {}

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        client_id = str(uuid.uuid4())

        self.connections[websocket] = {
            "id": client_id,
            "name": "Operator",
            "callsign": "GCS",
            "connected_at": now(),
        }

        await self.broadcast_user_list()
        return client_id

    async def disconnect(self, websocket: WebSocket):
        self.connections.pop(websocket, None)
        await self.broadcast_user_list()

    async def broadcast(self, payload):
        message = json.dumps(payload, ensure_ascii=False, default=str)
        dead = []

        for websocket in list(self.connections.keys()):
            try:
                await websocket.send_text(message)
            except Exception:
                dead.append(websocket)

        for websocket in dead:
            self.connections.pop(websocket, None)

    async def send(self, websocket: WebSocket, payload):
        try:
            await websocket.send_text(
                json.dumps(payload, ensure_ascii=False, default=str)
            )
        except Exception:
            pass

    async def broadcast_user_list(self):
        await self.broadcast({
            "type": "USER_LIST",
            "data": list(self.connections.values())
        })


manager = ConnectionManager()


async def mock_ai_risk_task():
    last_alert_time = 0

    while True:
        risk_data = {
            "fire": random.randint(0, 15),
            "smoke": random.randint(5, 25),
            "person": random.randint(60, 95),
            "hotspot": random.randint(20, 40),
        }

        await manager.broadcast({
            "type": "AI_RISK",
            "data": risk_data,
            "timestamp": now(),
        })

        dangerous = (
            risk_data["fire"] >= 12
            or risk_data["smoke"] >= 22
            or risk_data["hotspot"] >= 38
        )

        current_time = time.monotonic()

        if dangerous and current_time - last_alert_time >= 10:
            last_alert_time = current_time
            alert_id = str(uuid.uuid4())

            alert = {
                "id": alert_id,
                "level": "WARNING",
                "message": "AI 위험요소가 감지되었습니다.",
                "risk": risk_data,
                "acknowledged": False,
                "timestamp": now(),
            }

            alerts[alert_id] = alert
            create_event("AI_ALERT", alert, level="WARNING")

            await manager.broadcast({
                "type": "ALERT",
                "data": alert,
            })

        await asyncio.sleep(1)


async def relay_gcs_message(msg_type, data):
    no_log_types = {"TELEMETRY", "ATTITUDE", "GPS", "BATTERY"}

    if msg_type not in no_log_types:
        create_event(msg_type, data)

    await manager.broadcast({
        "type": msg_type,
        "data": data,
        "timestamp": now(),
    })


def gcs_callback(msg_type, data):
    global main_loop

    if not main_loop or not main_loop.is_running():
        return

    asyncio.run_coroutine_threadsafe(
        relay_gcs_message(msg_type, data),
        main_loop,
    )


drone = DroneManager(callback=gcs_callback)
video = VideoManager(callback=gcs_callback)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global main_loop

    main_loop = asyncio.get_running_loop()
    gcs_state["server_started"] = now()

    ai_task = asyncio.create_task(mock_ai_risk_task())
    create_event("SERVER_START", {"message": "GCS Server Started"})

    yield

    ai_task.cancel()
    try:
        await ai_task
    except asyncio.CancelledError:
        pass

    try:
        drone.stop()
    except Exception:
        pass

    try:
        video.stop()
    except Exception:
        pass


app = FastAPI(
    title="AI Drone GCS Server",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/")
async def get_index():
    file_path = os.path.join(base_dir, "index.html")

    if not os.path.exists(file_path):
        return {"error": f"index.html 파일을 찾을 수 없습니다: {file_path}"}

    return FileResponse(
        file_path,
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )


@app.get("/api/health")
async def health():
    return {
        "status": "OK",
        "server_time": now(),
        "clients": len(manager.connections),
        "gcs": gcs_state,
    }


@app.get("/api/events")
async def events(limit: int = 100):
    limit = min(max(limit, 1), 500)
    data = list(event_history)

    return {
        "count": len(data[-limit:]),
        "events": data[-limit:],
    }


@app.get("/api/chat")
async def get_chat_history(limit: int = 50):
    limit = min(max(limit, 1), 200)
    data = list(chat_history)

    return {
        "count": len(data[-limit:]),
        "messages": data[-limit:],
    }


@app.get("/api/alerts")
async def get_alerts():
    return {"alerts": list(alerts.values())}


async def handle_json_message(websocket: WebSocket, message: dict):
    msg_type = message.get("type")

    if msg_type == "HELLO":
        user = manager.connections.get(websocket)

        if user:
            user["name"] = str(message.get("name", "Operator"))[:30]
            user["callsign"] = str(message.get("callsign", "GCS"))[:20]

        await manager.broadcast_user_list()
        create_event("USER_LOGIN", user)

    elif msg_type == "CHAT":
        text = str(message.get("message", "")).strip()

        if not text:
            return

        text = text[:500]
        user = manager.connections.get(websocket, {})

        chat_message = {
            "id": str(uuid.uuid4()),
            "user_id": user.get("id"),
            "name": user.get("name", "Operator"),
            "callsign": user.get("callsign", "GCS"),
            "message": text,
            "timestamp": now(),
        }

        chat_history.append(chat_message)

        await manager.broadcast({
            "type": "CHAT",
            "data": chat_message,
        })

    elif msg_type == "DRONE_CONNECT":
        connection = str(message.get("connection", "")).strip()

        if not connection:
            await manager.send(
                websocket,
                {"type": "ERROR", "message": "connection 값이 없습니다."},
            )
            return

        try:
            drone.set_connection_string(connection)

            await asyncio.to_thread(drone.start)
            await asyncio.to_thread(video.start)

            gcs_state["drone_connected"] = True
            gcs_state["video_running"] = True
            gcs_state["connection_string"] = connection

            event = create_event(
                "DRONE_CONNECTED",
                {"connection": connection},
            )

            await manager.broadcast({
                "type": "SYSTEM_EVENT",
                "data": event,
            })

            await manager.broadcast({
                "type": "GCS_STATE",
                "data": gcs_state,
            })

        except Exception as e:
            await manager.send(
                websocket,
                {"type": "ERROR", "message": f"드론 연결 실패: {str(e)}"},
            )

    elif msg_type == "DRONE_DISCONNECT":
        try:
            await asyncio.to_thread(drone.stop)
            await asyncio.to_thread(video.stop)
        except Exception:
            pass

        gcs_state["drone_connected"] = False
        gcs_state["video_running"] = False

        event = create_event("DRONE_DISCONNECTED")

        await manager.broadcast({
            "type": "SYSTEM_EVENT",
            "data": event,
        })

        await manager.broadcast({
            "type": "GCS_STATE",
            "data": gcs_state,
        })

    elif msg_type == "DRONE_COMMAND":
        command = str(message.get("command", "")).upper()
        allowed_commands = {"ARM", "DISARM", "TAKEOFF", "LAND"}

        if command not in allowed_commands:
            await manager.send(
                websocket,
                {
                    "type": "ERROR",
                    "message": f"지원하지 않는 명령: {command}",
                },
            )
            return

        try:
            await asyncio.to_thread(drone.send_command, command)

            gcs_state["last_command"] = command
            user = manager.connections.get(websocket, {})

            event = create_event(
                "DRONE_COMMAND",
                {
                    "command": command,
                    "operator": user.get("name"),
                    "callsign": user.get("callsign"),
                },
            )

            await manager.broadcast({
                "type": "COMMAND_RESULT",
                "data": {
                    "success": True,
                    "command": command,
                    "event": event,
                },
            })

        except Exception as e:
            await manager.send(
                websocket,
                {
                    "type": "COMMAND_RESULT",
                    "data": {
                        "success": False,
                        "command": command,
                        "error": str(e),
                    },
                },
            )

    elif msg_type == "ALERT_ACK":
        alert_id = message.get("alert_id")

        if alert_id in alerts:
            user = manager.connections.get(websocket, {})

            alerts[alert_id]["acknowledged"] = True
            alerts[alert_id]["acknowledged_by"] = user.get("name")
            alerts[alert_id]["acknowledged_at"] = now()

            event = create_event("ALERT_ACK", alerts[alert_id])

            await manager.broadcast({
                "type": "ALERT_ACK",
                "data": event,
            })

    elif msg_type == "PING":
        await manager.send(
            websocket,
            {"type": "PONG", "timestamp": now()},
        )

    else:
        await manager.send(
            websocket,
            {
                "type": "ERROR",
                "message": f"알 수 없는 메시지 타입: {msg_type}",
            },
        )


async def handle_legacy_message(websocket: WebSocket, command: str):
    if command.startswith("CONNECT:"):
        connection = command.split("CONNECT:", 1)[1]

        await handle_json_message(
            websocket,
            {
                "type": "DRONE_CONNECT",
                "connection": connection,
            },
        )

    elif command == "DISCONNECT":
        await handle_json_message(
            websocket,
            {"type": "DRONE_DISCONNECT"},
        )

    elif command in ["ARM", "DISARM", "TAKEOFF", "LAND"]:
        await handle_json_message(
            websocket,
            {
                "type": "DRONE_COMMAND",
                "command": command,
            },
        )


@app.websocket("/ws/drone")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)

    await manager.send(
        websocket,
        {
            "type": "INITIAL_STATE",
            "data": {
                "gcs": gcs_state,
                "chat": list(chat_history)[-50:],
                "alerts": list(alerts.values()),
                "events": list(event_history)[-50:],
            },
        },
    )

    try:
        while True:
            raw_message = await websocket.receive_text()

            try:
                data = json.loads(raw_message)

                if isinstance(data, dict):
                    await handle_json_message(websocket, data)
                    continue

            except json.JSONDecodeError:
                pass

            await handle_legacy_message(websocket, raw_message)

    except WebSocketDisconnect:
        await manager.disconnect(websocket)

    except Exception as e:
        print(f"[WebSocket ERROR] {e}")
        await manager.disconnect(websocket)


if __name__ == "__main__":
    url = "http://localhost:8000"

    def open_browser():
        try:
            chrome_path = "C:/Program Files/Google/Chrome/Application/chrome.exe %s"
            webbrowser.get(chrome_path).open(url)
        except Exception:
            webbrowser.open(url)

    threading.Timer(1.5, open_browser).start()

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        ws="wsproto",
    )
