# video_manager.py
"""
기본 실행용 VideoManager 예제입니다.
실제 RTSP / WebRTC / OpenCV 코드가 있다면 교체하세요.
"""


class VideoManager:
    def __init__(self, callback=None):
        self.callback = callback
        self.running = False

    def start(self):
        self.running = True

        if self.callback:
            self.callback(
                "VIDEO_STATUS",
                {
                    "running": True,
                    "message": "Video manager started",
                },
            )

    def stop(self):
        self.running = False

        if self.callback:
            self.callback(
                "VIDEO_STATUS",
                {
                    "running": False,
                    "message": "Video manager stopped",
                },
            )
