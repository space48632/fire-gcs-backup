let ws = null;

function wsUrl() {
    const protocol = location.protocol === "https:" ? "wss" : "ws";
    return `${protocol}://${location.host}/ws/drone`;
}

function connectWebSocket() {
    ws = new WebSocket(wsUrl());

    ws.onopen = () => {
        setServerStatus(true);
        addEvent("WebSocket connected");
        sendHello();
    };

    ws.onclose = () => {
        setServerStatus(false);
        addEvent("WebSocket disconnected");
        setTimeout(connectWebSocket, 1500);
    };

    ws.onerror = () => {
        addEvent("WebSocket error");
    };

    ws.onmessage = (event) => {
        let msg;

        try {
            msg = JSON.parse(event.data);
        } catch {
            return;
        }

        switch (msg.type) {
            case "INITIAL_STATE":
                applyInitialState(msg.data);
                break;

            case "CHAT":
                showChat(msg.data);
                break;

            case "AI_RISK":
                updateAIRisk(msg.data);
                break;

            case "TELEMETRY":
                updateTelemetry(msg.data);
                break;

            case "SYSTEM_EVENT":
            case "COMMAND_RESULT":
            case "DRONE_STATUS":
            case "VIDEO_STATUS":
            case "ALERT":
            case "ALERT_ACK":
            case "ERROR":
                addEvent(JSON.stringify(msg));
                break;
        }
    };
}

function sendJson(data) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        addEvent("WebSocket is not connected");
        return;
    }

    ws.send(JSON.stringify(data));
}

function setServerStatus(connected) {
    const el = document.getElementById("serverStatus");
    el.textContent = connected ? "SERVER ONLINE" : "SERVER OFFLINE";
    el.className = `status ${connected ? "connected" : "disconnected"}`;
}

function sendHello() {
    sendJson({
        type: "HELLO",
        name: document.getElementById("operatorName").value || "Operator",
        callsign: document.getElementById("callsign").value || "GCS-01",
    });
}

function sendChat() {
    const input = document.getElementById("chatInput");
    const message = input.value.trim();

    if (!message) return;

    sendJson({
        type: "CHAT",
        message,
    });

    input.value = "";
}

function showChat(data) {
    const area = document.getElementById("chatMessages");
    const row = document.createElement("div");
    row.className = "chat-message";

    const user = document.createElement("strong");
    user.textContent = `[${data.callsign}] ${data.name}: `;

    const text = document.createElement("span");
    text.textContent = data.message;

    row.appendChild(user);
    row.appendChild(text);
    area.appendChild(row);
    area.scrollTop = area.scrollHeight;
}

function connectDrone() {
    const connection = document.getElementById("connectionInput").value.trim();

    sendJson({
        type: "DRONE_CONNECT",
        connection,
    });
}

function disconnectDrone() {
    sendJson({
        type: "DRONE_DISCONNECT",
    });
}

function sendCommand(command) {
    sendJson({
        type: "DRONE_COMMAND",
        command,
    });
}

function updateAIRisk(data) {
    document.getElementById("fire").textContent = `${data.fire}%`;
    document.getElementById("smoke").textContent = `${data.smoke}%`;
    document.getElementById("person").textContent = `${data.person}%`;
    document.getElementById("hotspot").textContent = `${data.hotspot}%`;
}

function updateTelemetry(data) {
    document.getElementById("altitude").textContent = `${data.altitude ?? 0} m`;
    document.getElementById("speed").textContent = `${data.speed ?? 0} m/s`;
    document.getElementById("battery").textContent = `${data.battery ?? 0}%`;
    document.getElementById("satellites").textContent = data.satellites ?? 0;
    document.getElementById("mode").textContent = data.mode ?? "-";
    document.getElementById("armed").textContent = String(data.armed ?? false).toUpperCase();
}

function addEvent(text) {
    const log = document.getElementById("eventLog");
    const row = document.createElement("div");
    row.textContent = `[${new Date().toLocaleTimeString()}] ${text}`;
    log.prepend(row);
}

function applyInitialState(data) {
    if (Array.isArray(data.chat)) {
        data.chat.forEach(showChat);
    }

    if (Array.isArray(data.events)) {
        data.events.slice().reverse().forEach((event) => {
            addEvent(`${event.type} ${JSON.stringify(event.data)}`);
        });
    }
}

connectWebSocket();
