# AI Drone GCS

FastAPI + WebSocket 기반의 드론 관제시스템(GCS) 스타터 프로젝트입니다.

## 주요 기능

- 드론 연결 / 해제
- ARM / DISARM / TAKEOFF / LAND 명령
- WebSocket 실시간 통신
- 관제사 채팅
- 사용자 호출부호
- 실시간 텔레메트리
- AI 위험도 Mock 데이터
- AI Alert / ACK 구조
- 이벤트 로그
- REST API
- 브라우저 자동 실행
- GitHub 업로드용 기본 구조

## 프로젝트 구조

```text
ai_drone_gcs/
├─ main.py
├─ drone_manager.py
├─ video_manager.py
├─ index.html
├─ requirements.txt
├─ .gitignore
├─ README.md
└─ static/
   ├─ app.js
   └─ style.css
```

## 설치

Python 3.10 이상 권장.

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
```

패키지 설치:

```bash
pip install -r requirements.txt
```

## 실행

```bash
python main.py
```

브라우저:

```text
http://localhost:8000
```

## WebSocket

```text
/ws/drone
```

예시:

```json
{
  "type": "DRONE_COMMAND",
  "command": "ARM"
}
```

채팅:

```json
{
  "type": "CHAT",
  "message": "GCS-01 통신 확인"
}
```

드론 연결:

```json
{
  "type": "DRONE_CONNECT",
  "connection": "udp:127.0.0.1:14550"
}
```

## 실제 Pixhawk / MAVLink 연결

현재 포함된 `drone_manager.py`는 GitHub에서 바로 실행해볼 수 있도록 만든 Mock 버전입니다.

기존에 실제 Pixhawk / pymavlink / MAVSDK 기반 `drone_manager.py`가 있다면 아래 인터페이스만 유지해서 교체하면 됩니다.

```python
DroneManager(callback=...)
set_connection_string(connection_string)
start()
stop()
send_command(command)
```

`video_manager.py` 역시 실제 RTSP / WebRTC / OpenCV 영상 처리 코드로 교체할 수 있습니다.

## 다음 확장 추천

- MAVLink 실제 Telemetry 연결
- RTL / GUIDED / AUTO
- 고도 지정 TAKEOFF
- Waypoint Mission
- Leaflet / MapLibre 지도
- 실시간 GPS 트랙
- 다중 드론 관제
- SQLite / PostgreSQL 비행로그
- 로그인 / 권한관리
- WebRTC 영상 스트리밍
- YOLO 객체감지 연동

## GitHub 업로드

```bash
git init
git add .
git commit -m "Initial AI Drone GCS"
git branch -M main
git remote add origin https://github.com/YOUR_ID/YOUR_REPOSITORY.git
git push -u origin main
```

## 주의

개발용 CORS 설정은 모든 Origin을 허용합니다.

운영 배포 시에는:

```python
allow_origins=["https://your-domain.com"]
```

처럼 허용 도메인을 제한하는 것을 권장합니다.
